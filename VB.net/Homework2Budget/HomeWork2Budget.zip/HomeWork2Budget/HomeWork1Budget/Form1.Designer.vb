﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblTuition = New System.Windows.Forms.Label()
        Me.lblHousing = New System.Windows.Forms.Label()
        Me.lblBooksAndSupplies = New System.Windows.Forms.Label()
        Me.lblTransportaion = New System.Windows.Forms.Label()
        Me.lblFood = New System.Windows.Forms.Label()
        Me.lblUtilities = New System.Windows.Forms.Label()
        Me.lblDebt = New System.Windows.Forms.Label()
        Me.lblInsurance = New System.Windows.Forms.Label()
        Me.lblEntertainment = New System.Windows.Forms.Label()
        Me.lblClothing = New System.Windows.Forms.Label()
        Me.lblMisc = New System.Windows.Forms.Label()
        Me.grpExpenses = New System.Windows.Forms.GroupBox()
        Me.txtTotalExpenses = New System.Windows.Forms.TextBox()
        Me.lblTotalExpeneses = New System.Windows.Forms.Label()
        Me.txtMisc = New System.Windows.Forms.TextBox()
        Me.txtClothing = New System.Windows.Forms.TextBox()
        Me.txtEntertainment = New System.Windows.Forms.TextBox()
        Me.txtInsurance = New System.Windows.Forms.TextBox()
        Me.txtDebt = New System.Windows.Forms.TextBox()
        Me.txtUtilities = New System.Windows.Forms.TextBox()
        Me.txtFood = New System.Windows.Forms.TextBox()
        Me.txtTransportation = New System.Windows.Forms.TextBox()
        Me.txtBooksAndSupplies = New System.Windows.Forms.TextBox()
        Me.txtHousing = New System.Windows.Forms.TextBox()
        Me.txtTuition = New System.Windows.Forms.TextBox()
        Me.grpIncome = New System.Windows.Forms.GroupBox()
        Me.txtTotalIncome = New System.Windows.Forms.TextBox()
        Me.lblTotalIncome = New System.Windows.Forms.Label()
        Me.txtSavings = New System.Windows.Forms.TextBox()
        Me.lblSavings = New System.Windows.Forms.Label()
        Me.txtParents = New System.Windows.Forms.TextBox()
        Me.lblParents = New System.Windows.Forms.Label()
        Me.txtScholarships = New System.Windows.Forms.TextBox()
        Me.lblScholarships = New System.Windows.Forms.Label()
        Me.txtSalary = New System.Windows.Forms.TextBox()
        Me.lblSalary = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtBalance = New System.Windows.Forms.TextBox()
        Me.txtPercentTuition = New System.Windows.Forms.TextBox()
        Me.txtPercentHousing = New System.Windows.Forms.TextBox()
        Me.txtPercentBooks = New System.Windows.Forms.TextBox()
        Me.txtPercentTrans = New System.Windows.Forms.TextBox()
        Me.txtPercentFood = New System.Windows.Forms.TextBox()
        Me.txtPercentUtil = New System.Windows.Forms.TextBox()
        Me.txtPercentDebt = New System.Windows.Forms.TextBox()
        Me.txtPercentInsur = New System.Windows.Forms.TextBox()
        Me.txtPercentEnt = New System.Windows.Forms.TextBox()
        Me.txtPercentCloth = New System.Windows.Forms.TextBox()
        Me.txtPercentMisc = New System.Windows.Forms.TextBox()
        Me.txtPercentSalary = New System.Windows.Forms.TextBox()
        Me.txtPercentSchol = New System.Windows.Forms.TextBox()
        Me.txtPercentParents = New System.Windows.Forms.TextBox()
        Me.txtPercentSaving = New System.Windows.Forms.TextBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.grpExpenses.SuspendLayout()
        Me.grpIncome.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(316, 46)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(75, 23)
        Me.btnCalc.TabIndex = 2
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(316, 91)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 3
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(316, 138)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblTuition
        '
        Me.lblTuition.AutoSize = True
        Me.lblTuition.Location = New System.Drawing.Point(6, 16)
        Me.lblTuition.Name = "lblTuition"
        Me.lblTuition.Size = New System.Drawing.Size(39, 13)
        Me.lblTuition.TabIndex = 12
        Me.lblTuition.Text = "Tuition"
        '
        'lblHousing
        '
        Me.lblHousing.AutoSize = True
        Me.lblHousing.Location = New System.Drawing.Point(5, 39)
        Me.lblHousing.Name = "lblHousing"
        Me.lblHousing.Size = New System.Drawing.Size(46, 13)
        Me.lblHousing.TabIndex = 13
        Me.lblHousing.Text = "Housing"
        '
        'lblBooksAndSupplies
        '
        Me.lblBooksAndSupplies.AutoSize = True
        Me.lblBooksAndSupplies.Location = New System.Drawing.Point(6, 62)
        Me.lblBooksAndSupplies.Name = "lblBooksAndSupplies"
        Me.lblBooksAndSupplies.Size = New System.Drawing.Size(133, 13)
        Me.lblBooksAndSupplies.TabIndex = 14
        Me.lblBooksAndSupplies.Text = "Books and school supplies"
        '
        'lblTransportaion
        '
        Me.lblTransportaion.AutoSize = True
        Me.lblTransportaion.Location = New System.Drawing.Point(6, 84)
        Me.lblTransportaion.Name = "lblTransportaion"
        Me.lblTransportaion.Size = New System.Drawing.Size(75, 13)
        Me.lblTransportaion.TabIndex = 15
        Me.lblTransportaion.Text = "Transportation"
        '
        'lblFood
        '
        Me.lblFood.AutoSize = True
        Me.lblFood.Location = New System.Drawing.Point(6, 103)
        Me.lblFood.Name = "lblFood"
        Me.lblFood.Size = New System.Drawing.Size(31, 13)
        Me.lblFood.TabIndex = 16
        Me.lblFood.Text = "Food"
        '
        'lblUtilities
        '
        Me.lblUtilities.AutoSize = True
        Me.lblUtilities.Location = New System.Drawing.Point(6, 126)
        Me.lblUtilities.Name = "lblUtilities"
        Me.lblUtilities.Size = New System.Drawing.Size(40, 13)
        Me.lblUtilities.TabIndex = 17
        Me.lblUtilities.Text = "Utilities"
        '
        'lblDebt
        '
        Me.lblDebt.AutoSize = True
        Me.lblDebt.Location = New System.Drawing.Point(6, 149)
        Me.lblDebt.Name = "lblDebt"
        Me.lblDebt.Size = New System.Drawing.Size(30, 13)
        Me.lblDebt.TabIndex = 18
        Me.lblDebt.Text = "Debt"
        '
        'lblInsurance
        '
        Me.lblInsurance.AutoSize = True
        Me.lblInsurance.Location = New System.Drawing.Point(6, 172)
        Me.lblInsurance.Name = "lblInsurance"
        Me.lblInsurance.Size = New System.Drawing.Size(54, 13)
        Me.lblInsurance.TabIndex = 19
        Me.lblInsurance.Text = "Insurance"
        '
        'lblEntertainment
        '
        Me.lblEntertainment.AutoSize = True
        Me.lblEntertainment.Location = New System.Drawing.Point(6, 196)
        Me.lblEntertainment.Name = "lblEntertainment"
        Me.lblEntertainment.Size = New System.Drawing.Size(72, 13)
        Me.lblEntertainment.TabIndex = 20
        Me.lblEntertainment.Text = "Entertainment"
        '
        'lblClothing
        '
        Me.lblClothing.AutoSize = True
        Me.lblClothing.Location = New System.Drawing.Point(6, 219)
        Me.lblClothing.Name = "lblClothing"
        Me.lblClothing.Size = New System.Drawing.Size(45, 13)
        Me.lblClothing.TabIndex = 21
        Me.lblClothing.Text = "Clothing"
        '
        'lblMisc
        '
        Me.lblMisc.AutoSize = True
        Me.lblMisc.Location = New System.Drawing.Point(6, 241)
        Me.lblMisc.Name = "lblMisc"
        Me.lblMisc.Size = New System.Drawing.Size(74, 13)
        Me.lblMisc.TabIndex = 22
        Me.lblMisc.Text = "Miscellaneous"
        '
        'grpExpenses
        '
        Me.grpExpenses.BackColor = System.Drawing.SystemColors.Control
        Me.grpExpenses.Controls.Add(Me.txtPercentHousing)
        Me.grpExpenses.Controls.Add(Me.txtPercentMisc)
        Me.grpExpenses.Controls.Add(Me.txtPercentCloth)
        Me.grpExpenses.Controls.Add(Me.txtPercentEnt)
        Me.grpExpenses.Controls.Add(Me.txtPercentInsur)
        Me.grpExpenses.Controls.Add(Me.txtPercentDebt)
        Me.grpExpenses.Controls.Add(Me.txtPercentUtil)
        Me.grpExpenses.Controls.Add(Me.txtPercentFood)
        Me.grpExpenses.Controls.Add(Me.txtPercentTrans)
        Me.grpExpenses.Controls.Add(Me.txtPercentBooks)
        Me.grpExpenses.Controls.Add(Me.txtPercentTuition)
        Me.grpExpenses.Controls.Add(Me.txtTotalExpenses)
        Me.grpExpenses.Controls.Add(Me.lblTotalExpeneses)
        Me.grpExpenses.Controls.Add(Me.txtMisc)
        Me.grpExpenses.Controls.Add(Me.txtClothing)
        Me.grpExpenses.Controls.Add(Me.txtEntertainment)
        Me.grpExpenses.Controls.Add(Me.txtInsurance)
        Me.grpExpenses.Controls.Add(Me.txtDebt)
        Me.grpExpenses.Controls.Add(Me.txtUtilities)
        Me.grpExpenses.Controls.Add(Me.txtFood)
        Me.grpExpenses.Controls.Add(Me.txtTransportation)
        Me.grpExpenses.Controls.Add(Me.txtBooksAndSupplies)
        Me.grpExpenses.Controls.Add(Me.txtHousing)
        Me.grpExpenses.Controls.Add(Me.txtTuition)
        Me.grpExpenses.Controls.Add(Me.lblMisc)
        Me.grpExpenses.Controls.Add(Me.lblTuition)
        Me.grpExpenses.Controls.Add(Me.lblHousing)
        Me.grpExpenses.Controls.Add(Me.lblBooksAndSupplies)
        Me.grpExpenses.Controls.Add(Me.lblTransportaion)
        Me.grpExpenses.Controls.Add(Me.lblFood)
        Me.grpExpenses.Controls.Add(Me.lblUtilities)
        Me.grpExpenses.Controls.Add(Me.lblDebt)
        Me.grpExpenses.Controls.Add(Me.lblInsurance)
        Me.grpExpenses.Controls.Add(Me.lblEntertainment)
        Me.grpExpenses.Controls.Add(Me.lblClothing)
        Me.grpExpenses.Location = New System.Drawing.Point(12, 12)
        Me.grpExpenses.Name = "grpExpenses"
        Me.grpExpenses.Size = New System.Drawing.Size(298, 288)
        Me.grpExpenses.TabIndex = 0
        Me.grpExpenses.TabStop = False
        Me.grpExpenses.Text = "Expenses"
        '
        'txtTotalExpenses
        '
        Me.txtTotalExpenses.Location = New System.Drawing.Point(154, 260)
        Me.txtTotalExpenses.Name = "txtTotalExpenses"
        Me.txtTotalExpenses.ReadOnly = True
        Me.txtTotalExpenses.Size = New System.Drawing.Size(70, 20)
        Me.txtTotalExpenses.TabIndex = 11
        Me.txtTotalExpenses.TabStop = False
        Me.txtTotalExpenses.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblTotalExpeneses
        '
        Me.lblTotalExpeneses.AutoSize = True
        Me.lblTotalExpeneses.Location = New System.Drawing.Point(6, 263)
        Me.lblTotalExpeneses.Name = "lblTotalExpeneses"
        Me.lblTotalExpeneses.Size = New System.Drawing.Size(79, 13)
        Me.lblTotalExpeneses.TabIndex = 23
        Me.lblTotalExpeneses.Text = "Total expenses"
        '
        'txtMisc
        '
        Me.txtMisc.Location = New System.Drawing.Point(154, 238)
        Me.txtMisc.Name = "txtMisc"
        Me.txtMisc.Size = New System.Drawing.Size(70, 20)
        Me.txtMisc.TabIndex = 10
        '
        'txtClothing
        '
        Me.txtClothing.Location = New System.Drawing.Point(154, 216)
        Me.txtClothing.Name = "txtClothing"
        Me.txtClothing.Size = New System.Drawing.Size(70, 20)
        Me.txtClothing.TabIndex = 9
        '
        'txtEntertainment
        '
        Me.txtEntertainment.Location = New System.Drawing.Point(154, 193)
        Me.txtEntertainment.Name = "txtEntertainment"
        Me.txtEntertainment.Size = New System.Drawing.Size(70, 20)
        Me.txtEntertainment.TabIndex = 8
        '
        'txtInsurance
        '
        Me.txtInsurance.Location = New System.Drawing.Point(154, 169)
        Me.txtInsurance.Name = "txtInsurance"
        Me.txtInsurance.Size = New System.Drawing.Size(70, 20)
        Me.txtInsurance.TabIndex = 7
        '
        'txtDebt
        '
        Me.txtDebt.Location = New System.Drawing.Point(154, 146)
        Me.txtDebt.Name = "txtDebt"
        Me.txtDebt.Size = New System.Drawing.Size(70, 20)
        Me.txtDebt.TabIndex = 6
        '
        'txtUtilities
        '
        Me.txtUtilities.Location = New System.Drawing.Point(154, 123)
        Me.txtUtilities.Name = "txtUtilities"
        Me.txtUtilities.Size = New System.Drawing.Size(70, 20)
        Me.txtUtilities.TabIndex = 5
        '
        'txtFood
        '
        Me.txtFood.Location = New System.Drawing.Point(154, 100)
        Me.txtFood.Name = "txtFood"
        Me.txtFood.Size = New System.Drawing.Size(70, 20)
        Me.txtFood.TabIndex = 4
        '
        'txtTransportation
        '
        Me.txtTransportation.Location = New System.Drawing.Point(154, 77)
        Me.txtTransportation.Name = "txtTransportation"
        Me.txtTransportation.Size = New System.Drawing.Size(70, 20)
        Me.txtTransportation.TabIndex = 3
        '
        'txtBooksAndSupplies
        '
        Me.txtBooksAndSupplies.Location = New System.Drawing.Point(154, 55)
        Me.txtBooksAndSupplies.Name = "txtBooksAndSupplies"
        Me.txtBooksAndSupplies.Size = New System.Drawing.Size(70, 20)
        Me.txtBooksAndSupplies.TabIndex = 2
        '
        'txtHousing
        '
        Me.txtHousing.Location = New System.Drawing.Point(154, 32)
        Me.txtHousing.Name = "txtHousing"
        Me.txtHousing.Size = New System.Drawing.Size(70, 20)
        Me.txtHousing.TabIndex = 1
        '
        'txtTuition
        '
        Me.txtTuition.Location = New System.Drawing.Point(154, 9)
        Me.txtTuition.Name = "txtTuition"
        Me.txtTuition.Size = New System.Drawing.Size(70, 20)
        Me.txtTuition.TabIndex = 0
        '
        'grpIncome
        '
        Me.grpIncome.Controls.Add(Me.txtPercentSaving)
        Me.grpIncome.Controls.Add(Me.txtPercentParents)
        Me.grpIncome.Controls.Add(Me.txtPercentSchol)
        Me.grpIncome.Controls.Add(Me.txtPercentSalary)
        Me.grpIncome.Controls.Add(Me.txtTotalIncome)
        Me.grpIncome.Controls.Add(Me.lblTotalIncome)
        Me.grpIncome.Controls.Add(Me.txtSavings)
        Me.grpIncome.Controls.Add(Me.lblSavings)
        Me.grpIncome.Controls.Add(Me.txtParents)
        Me.grpIncome.Controls.Add(Me.lblParents)
        Me.grpIncome.Controls.Add(Me.txtScholarships)
        Me.grpIncome.Controls.Add(Me.lblScholarships)
        Me.grpIncome.Controls.Add(Me.txtSalary)
        Me.grpIncome.Controls.Add(Me.lblSalary)
        Me.grpIncome.Location = New System.Drawing.Point(12, 306)
        Me.grpIncome.Name = "grpIncome"
        Me.grpIncome.Size = New System.Drawing.Size(298, 135)
        Me.grpIncome.TabIndex = 1
        Me.grpIncome.TabStop = False
        Me.grpIncome.Text = "Sources of Income"
        '
        'txtTotalIncome
        '
        Me.txtTotalIncome.Location = New System.Drawing.Point(154, 105)
        Me.txtTotalIncome.Name = "txtTotalIncome"
        Me.txtTotalIncome.ReadOnly = True
        Me.txtTotalIncome.Size = New System.Drawing.Size(70, 20)
        Me.txtTotalIncome.TabIndex = 4
        Me.txtTotalIncome.TabStop = False
        '
        'lblTotalIncome
        '
        Me.lblTotalIncome.AutoSize = True
        Me.lblTotalIncome.Location = New System.Drawing.Point(5, 108)
        Me.lblTotalIncome.Name = "lblTotalIncome"
        Me.lblTotalIncome.Size = New System.Drawing.Size(68, 13)
        Me.lblTotalIncome.TabIndex = 9
        Me.lblTotalIncome.Text = "Total income"
        '
        'txtSavings
        '
        Me.txtSavings.Location = New System.Drawing.Point(154, 81)
        Me.txtSavings.Name = "txtSavings"
        Me.txtSavings.Size = New System.Drawing.Size(70, 20)
        Me.txtSavings.TabIndex = 3
        '
        'lblSavings
        '
        Me.lblSavings.AutoSize = True
        Me.lblSavings.Location = New System.Drawing.Point(6, 84)
        Me.lblSavings.Name = "lblSavings"
        Me.lblSavings.Size = New System.Drawing.Size(45, 13)
        Me.lblSavings.TabIndex = 8
        Me.lblSavings.Text = "Savings"
        '
        'txtParents
        '
        Me.txtParents.Location = New System.Drawing.Point(154, 58)
        Me.txtParents.Name = "txtParents"
        Me.txtParents.Size = New System.Drawing.Size(70, 20)
        Me.txtParents.TabIndex = 2
        '
        'lblParents
        '
        Me.lblParents.AutoSize = True
        Me.lblParents.Location = New System.Drawing.Point(6, 61)
        Me.lblParents.Name = "lblParents"
        Me.lblParents.Size = New System.Drawing.Size(77, 13)
        Me.lblParents.TabIndex = 7
        Me.lblParents.Text = "Parents/Family"
        '
        'txtScholarships
        '
        Me.txtScholarships.Location = New System.Drawing.Point(154, 36)
        Me.txtScholarships.Name = "txtScholarships"
        Me.txtScholarships.Size = New System.Drawing.Size(70, 20)
        Me.txtScholarships.TabIndex = 1
        '
        'lblScholarships
        '
        Me.lblScholarships.AutoSize = True
        Me.lblScholarships.Location = New System.Drawing.Point(6, 39)
        Me.lblScholarships.Name = "lblScholarships"
        Me.lblScholarships.Size = New System.Drawing.Size(125, 13)
        Me.lblScholarships.TabIndex = 6
        Me.lblScholarships.Text = "Scholarships/grants, etc."
        '
        'txtSalary
        '
        Me.txtSalary.Location = New System.Drawing.Point(154, 13)
        Me.txtSalary.Name = "txtSalary"
        Me.txtSalary.Size = New System.Drawing.Size(70, 20)
        Me.txtSalary.TabIndex = 0
        '
        'lblSalary
        '
        Me.lblSalary.AutoSize = True
        Me.lblSalary.Location = New System.Drawing.Point(5, 16)
        Me.lblSalary.Name = "lblSalary"
        Me.lblSalary.Size = New System.Drawing.Size(36, 13)
        Me.lblSalary.TabIndex = 5
        Me.lblSalary.Text = "Salary"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 444)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Balance"
        '
        'txtBalance
        '
        Me.txtBalance.Location = New System.Drawing.Point(166, 444)
        Me.txtBalance.Name = "txtBalance"
        Me.txtBalance.ReadOnly = True
        Me.txtBalance.Size = New System.Drawing.Size(70, 20)
        Me.txtBalance.TabIndex = 6
        Me.txtBalance.TabStop = False
        '
        'txtPercentTuition
        '
        Me.txtPercentTuition.Location = New System.Drawing.Point(230, 9)
        Me.txtPercentTuition.Name = "txtPercentTuition"
        Me.txtPercentTuition.ReadOnly = True
        Me.txtPercentTuition.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentTuition.TabIndex = 24
        Me.txtPercentTuition.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentTuition, "Percent of expenses")
        '
        'txtPercentHousing
        '
        Me.txtPercentHousing.Location = New System.Drawing.Point(230, 32)
        Me.txtPercentHousing.Name = "txtPercentHousing"
        Me.txtPercentHousing.ReadOnly = True
        Me.txtPercentHousing.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentHousing.TabIndex = 25
        Me.txtPercentHousing.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentHousing, "Percent of expenses")
        '
        'txtPercentBooks
        '
        Me.txtPercentBooks.Location = New System.Drawing.Point(230, 55)
        Me.txtPercentBooks.Name = "txtPercentBooks"
        Me.txtPercentBooks.ReadOnly = True
        Me.txtPercentBooks.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentBooks.TabIndex = 25
        Me.txtPercentBooks.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentBooks, "Percent of expenses")
        '
        'txtPercentTrans
        '
        Me.txtPercentTrans.Location = New System.Drawing.Point(230, 77)
        Me.txtPercentTrans.Name = "txtPercentTrans"
        Me.txtPercentTrans.ReadOnly = True
        Me.txtPercentTrans.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentTrans.TabIndex = 26
        Me.txtPercentTrans.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentTrans, "Percent of expenses")
        '
        'txtPercentFood
        '
        Me.txtPercentFood.Location = New System.Drawing.Point(230, 100)
        Me.txtPercentFood.Name = "txtPercentFood"
        Me.txtPercentFood.ReadOnly = True
        Me.txtPercentFood.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentFood.TabIndex = 27
        Me.txtPercentFood.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentFood, "Percent of expenses")
        '
        'txtPercentUtil
        '
        Me.txtPercentUtil.Location = New System.Drawing.Point(230, 123)
        Me.txtPercentUtil.Name = "txtPercentUtil"
        Me.txtPercentUtil.ReadOnly = True
        Me.txtPercentUtil.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentUtil.TabIndex = 28
        Me.txtPercentUtil.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentUtil, "Percent of expenses")
        '
        'txtPercentDebt
        '
        Me.txtPercentDebt.Location = New System.Drawing.Point(230, 146)
        Me.txtPercentDebt.Name = "txtPercentDebt"
        Me.txtPercentDebt.ReadOnly = True
        Me.txtPercentDebt.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentDebt.TabIndex = 29
        Me.txtPercentDebt.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentDebt, "Percent of expenses")
        '
        'txtPercentInsur
        '
        Me.txtPercentInsur.Location = New System.Drawing.Point(230, 169)
        Me.txtPercentInsur.Name = "txtPercentInsur"
        Me.txtPercentInsur.ReadOnly = True
        Me.txtPercentInsur.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentInsur.TabIndex = 30
        Me.txtPercentInsur.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentInsur, "Percent of expenses")
        '
        'txtPercentEnt
        '
        Me.txtPercentEnt.Location = New System.Drawing.Point(230, 193)
        Me.txtPercentEnt.Name = "txtPercentEnt"
        Me.txtPercentEnt.ReadOnly = True
        Me.txtPercentEnt.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentEnt.TabIndex = 31
        Me.txtPercentEnt.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentEnt, "Percent of expenses")
        '
        'txtPercentCloth
        '
        Me.txtPercentCloth.Location = New System.Drawing.Point(230, 216)
        Me.txtPercentCloth.Name = "txtPercentCloth"
        Me.txtPercentCloth.ReadOnly = True
        Me.txtPercentCloth.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentCloth.TabIndex = 32
        Me.txtPercentCloth.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentCloth, "Percent of expenses")
        '
        'txtPercentMisc
        '
        Me.txtPercentMisc.Location = New System.Drawing.Point(230, 238)
        Me.txtPercentMisc.Name = "txtPercentMisc"
        Me.txtPercentMisc.ReadOnly = True
        Me.txtPercentMisc.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentMisc.TabIndex = 33
        Me.txtPercentMisc.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentMisc, "Percent of expenses")
        '
        'txtPercentSalary
        '
        Me.txtPercentSalary.Location = New System.Drawing.Point(230, 13)
        Me.txtPercentSalary.Name = "txtPercentSalary"
        Me.txtPercentSalary.ReadOnly = True
        Me.txtPercentSalary.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentSalary.TabIndex = 34
        Me.txtPercentSalary.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentSalary, "Percent of income")
        '
        'txtPercentSchol
        '
        Me.txtPercentSchol.Location = New System.Drawing.Point(230, 36)
        Me.txtPercentSchol.Name = "txtPercentSchol"
        Me.txtPercentSchol.ReadOnly = True
        Me.txtPercentSchol.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentSchol.TabIndex = 35
        Me.txtPercentSchol.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentSchol, "Percent of income")
        '
        'txtPercentParents
        '
        Me.txtPercentParents.Location = New System.Drawing.Point(230, 58)
        Me.txtPercentParents.Name = "txtPercentParents"
        Me.txtPercentParents.ReadOnly = True
        Me.txtPercentParents.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentParents.TabIndex = 36
        Me.txtPercentParents.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentParents, "Percent of income")
        '
        'txtPercentSaving
        '
        Me.txtPercentSaving.Location = New System.Drawing.Point(230, 81)
        Me.txtPercentSaving.Name = "txtPercentSaving"
        Me.txtPercentSaving.ReadOnly = True
        Me.txtPercentSaving.Size = New System.Drawing.Size(62, 20)
        Me.txtPercentSaving.TabIndex = 37
        Me.txtPercentSaving.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtPercentSaving, "Percent of income")
        '
        'Form1
        '
        Me.AcceptButton = Me.btnCalc
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(403, 472)
        Me.Controls.Add(Me.txtBalance)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.grpIncome)
        Me.Controls.Add(Me.grpExpenses)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalc)
        Me.Name = "Form1"
        Me.Text = "Semester Budget"
        Me.grpExpenses.ResumeLayout(False)
        Me.grpExpenses.PerformLayout()
        Me.grpIncome.ResumeLayout(False)
        Me.grpIncome.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalc As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblTuition As Label
    Friend WithEvents lblHousing As Label
    Friend WithEvents lblBooksAndSupplies As Label
    Friend WithEvents lblTransportaion As Label
    Friend WithEvents lblFood As Label
    Friend WithEvents lblUtilities As Label
    Friend WithEvents lblDebt As Label
    Friend WithEvents lblInsurance As Label
    Friend WithEvents lblEntertainment As Label
    Friend WithEvents lblClothing As Label
    Friend WithEvents lblMisc As Label
    Friend WithEvents grpExpenses As GroupBox
    Friend WithEvents txtHousing As TextBox
    Friend WithEvents txtTuition As TextBox
    Friend WithEvents txtTransportation As TextBox
    Friend WithEvents txtBooksAndSupplies As TextBox
    Friend WithEvents txtEntertainment As TextBox
    Friend WithEvents txtInsurance As TextBox
    Friend WithEvents txtDebt As TextBox
    Friend WithEvents txtUtilities As TextBox
    Friend WithEvents txtFood As TextBox
    Friend WithEvents txtClothing As TextBox
    Friend WithEvents txtMisc As TextBox
    Friend WithEvents grpIncome As GroupBox
    Friend WithEvents lblScholarships As Label
    Friend WithEvents txtSalary As TextBox
    Friend WithEvents lblSalary As Label
    Friend WithEvents txtParents As TextBox
    Friend WithEvents lblParents As Label
    Friend WithEvents txtScholarships As TextBox
    Friend WithEvents txtSavings As TextBox
    Friend WithEvents lblSavings As Label
    Friend WithEvents txtTotalExpenses As TextBox
    Friend WithEvents lblTotalExpeneses As Label
    Friend WithEvents txtTotalIncome As TextBox
    Friend WithEvents lblTotalIncome As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtBalance As TextBox
    Friend WithEvents txtPercentMisc As TextBox
    Friend WithEvents txtPercentCloth As TextBox
    Friend WithEvents txtPercentEnt As TextBox
    Friend WithEvents txtPercentInsur As TextBox
    Friend WithEvents txtPercentDebt As TextBox
    Friend WithEvents txtPercentUtil As TextBox
    Friend WithEvents txtPercentFood As TextBox
    Friend WithEvents txtPercentTrans As TextBox
    Friend WithEvents txtPercentBooks As TextBox
    Friend WithEvents txtPercentTuition As TextBox
    Friend WithEvents txtPercentSaving As TextBox
    Friend WithEvents txtPercentParents As TextBox
    Friend WithEvents txtPercentSchol As TextBox
    Friend WithEvents txtPercentSalary As TextBox
    Friend WithEvents txtPercentHousing As TextBox
    Friend WithEvents ToolTip1 As ToolTip
End Class
