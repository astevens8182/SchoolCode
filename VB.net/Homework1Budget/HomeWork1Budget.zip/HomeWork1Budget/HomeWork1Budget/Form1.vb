﻿'Author: Alex Stevens'
'Date: 01/18/2018'
'Assignment: Homework 1'
Option Strict On

Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles grpExpenses.Enter

    End Sub

    Private Sub lblDebt_Click(sender As Object, e As EventArgs) Handles lblDebt.Click

    End Sub

    Private Sub lblHousing_Click(sender As Object, e As EventArgs) Handles lblHousing.Click

    End Sub

    Private Sub lblTransportaion_Click(sender As Object, e As EventArgs) Handles lblTransportaion.Click

    End Sub

    Private Sub lblUtilities_Click(sender As Object, e As EventArgs) Handles lblUtilities.Click

    End Sub

    Private Sub lblInsurance_Click(sender As Object, e As EventArgs) Handles lblInsurance.Click

    End Sub

    Private Sub txtTuition_TextChanged(sender As Object, e As EventArgs) Handles txtTuition.TextChanged

    End Sub

    Private Sub lblClothing_Click(sender As Object, e As EventArgs) Handles lblClothing.Click

    End Sub

    Private Sub lblMisc_Click(sender As Object, e As EventArgs) Handles lblMisc.Click

    End Sub

    Private Sub txtHousing_TextChanged(sender As Object, e As EventArgs) Handles txtHousing.TextChanged

    End Sub

    Private Sub txtTransportation_TextChanged(sender As Object, e As EventArgs) Handles txtTransportation.TextChanged

    End Sub

    Private Sub txtFood_TextChanged(sender As Object, e As EventArgs) Handles txtFood.TextChanged

    End Sub

    Private Sub Label1_Click_1(sender As Object, e As EventArgs) Handles lblScholarships.Click

    End Sub

    Private Sub lblParents_Click(sender As Object, e As EventArgs) Handles lblParents.Click

    End Sub

    Private Sub txtDebt_TextChanged(sender As Object, e As EventArgs) Handles txtDebt.TextChanged

    End Sub

    Private Sub txtClothing_TextChanged(sender As Object, e As EventArgs) Handles txtClothing.TextChanged

    End Sub
End Class
