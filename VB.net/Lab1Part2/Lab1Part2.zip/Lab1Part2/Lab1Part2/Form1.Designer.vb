﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.nudAirTemp = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.nudHumidity = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtHeatIndex = New System.Windows.Forms.TextBox()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        CType(Me.nudAirTemp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudHumidity, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(1, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Air temperature"
        '
        'nudAirTemp
        '
        Me.nudAirTemp.DecimalPlaces = 3
        Me.nudAirTemp.Location = New System.Drawing.Point(85, 7)
        Me.nudAirTemp.Name = "nudAirTemp"
        Me.nudAirTemp.Size = New System.Drawing.Size(68, 20)
        Me.nudAirTemp.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(1, 35)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Humidity"
        '
        'nudHumidity
        '
        Me.nudHumidity.DecimalPlaces = 3
        Me.nudHumidity.Location = New System.Drawing.Point(85, 35)
        Me.nudHumidity.Name = "nudHumidity"
        Me.nudHumidity.Size = New System.Drawing.Size(68, 20)
        Me.nudHumidity.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(1, 68)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "heat index"
        '
        'txtHeatIndex
        '
        Me.txtHeatIndex.Location = New System.Drawing.Point(85, 68)
        Me.txtHeatIndex.Name = "txtHeatIndex"
        Me.txtHeatIndex.ReadOnly = True
        Me.txtHeatIndex.Size = New System.Drawing.Size(68, 20)
        Me.txtHeatIndex.TabIndex = 5
        Me.txtHeatIndex.TabStop = False
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(4, 115)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(75, 23)
        Me.btnCalc.TabIndex = 6
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(85, 115)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 7
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(166, 115)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(257, 163)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.txtHeatIndex)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.nudHumidity)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.nudAirTemp)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Heat Index"
        CType(Me.nudAirTemp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudHumidity, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents nudAirTemp As NumericUpDown
    Friend WithEvents Label2 As Label
    Friend WithEvents nudHumidity As NumericUpDown
    Friend WithEvents Label3 As Label
    Friend WithEvents txtHeatIndex As TextBox
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
