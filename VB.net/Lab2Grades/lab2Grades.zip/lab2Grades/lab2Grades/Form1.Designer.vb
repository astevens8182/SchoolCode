﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtTestScores = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtNumScore = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtBestScore = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtWorstScore = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtAvgScore = New System.Windows.Forms.TextBox()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtletterGrade = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Test score"
        '
        'txtTestScores
        '
        Me.txtTestScores.Location = New System.Drawing.Point(110, 4)
        Me.txtTestScores.Name = "txtTestScores"
        Me.txtTestScores.Size = New System.Drawing.Size(59, 20)
        Me.txtTestScores.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(0, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(90, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Number of scores"
        '
        'txtNumScore
        '
        Me.txtNumScore.Location = New System.Drawing.Point(110, 27)
        Me.txtNumScore.Name = "txtNumScore"
        Me.txtNumScore.ReadOnly = True
        Me.txtNumScore.Size = New System.Drawing.Size(59, 20)
        Me.txtNumScore.TabIndex = 3
        Me.txtNumScore.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(33, 49)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Best score"
        '
        'txtBestScore
        '
        Me.txtBestScore.Location = New System.Drawing.Point(110, 49)
        Me.txtBestScore.Name = "txtBestScore"
        Me.txtBestScore.ReadOnly = True
        Me.txtBestScore.Size = New System.Drawing.Size(59, 20)
        Me.txtBestScore.TabIndex = 5
        Me.txtBestScore.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(26, 73)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Worst score"
        '
        'txtWorstScore
        '
        Me.txtWorstScore.Location = New System.Drawing.Point(110, 70)
        Me.txtWorstScore.Name = "txtWorstScore"
        Me.txtWorstScore.ReadOnly = True
        Me.txtWorstScore.Size = New System.Drawing.Size(59, 20)
        Me.txtWorstScore.TabIndex = 7
        Me.txtWorstScore.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(14, 95)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Average score"
        '
        'txtAvgScore
        '
        Me.txtAvgScore.Location = New System.Drawing.Point(110, 92)
        Me.txtAvgScore.Name = "txtAvgScore"
        Me.txtAvgScore.ReadOnly = True
        Me.txtAvgScore.Size = New System.Drawing.Size(59, 20)
        Me.txtAvgScore.TabIndex = 9
        Me.txtAvgScore.TabStop = False
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(186, 7)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(75, 23)
        Me.btnEnter.TabIndex = 1
        Me.btnEnter.Text = "Enter"
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(186, 36)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 2
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(186, 63)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'txtletterGrade
        '
        Me.txtletterGrade.Location = New System.Drawing.Point(110, 115)
        Me.txtletterGrade.Name = "txtletterGrade"
        Me.txtletterGrade.ReadOnly = True
        Me.txtletterGrade.Size = New System.Drawing.Size(59, 20)
        Me.txtletterGrade.TabIndex = 10
        Me.txtletterGrade.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(30, 118)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(60, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "letter grade"
        '
        'Form1
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(263, 141)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtletterGrade)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.txtAvgScore)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtWorstScore)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtBestScore)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtNumScore)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtTestScores)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Grades"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtTestScores As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtNumScore As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtBestScore As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtWorstScore As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtAvgScore As TextBox
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents txtletterGrade As TextBox
    Friend WithEvents Label6 As Label
End Class
