﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtFinalNum = New System.Windows.Forms.TextBox()
        Me.BtnAC = New System.Windows.Forms.Button()
        Me.BtnPlusMinus = New System.Windows.Forms.Button()
        Me.btnDivide = New System.Windows.Forms.Button()
        Me.BtnPercent = New System.Windows.Forms.Button()
        Me.BtnSeven = New System.Windows.Forms.Button()
        Me.btnMultiply = New System.Windows.Forms.Button()
        Me.BtnNine = New System.Windows.Forms.Button()
        Me.btnEight = New System.Windows.Forms.Button()
        Me.BtnMinus = New System.Windows.Forms.Button()
        Me.BtnSix = New System.Windows.Forms.Button()
        Me.BtFive = New System.Windows.Forms.Button()
        Me.BtnFour = New System.Windows.Forms.Button()
        Me.BtnThree = New System.Windows.Forms.Button()
        Me.btnPlus = New System.Windows.Forms.Button()
        Me.BtnTwo = New System.Windows.Forms.Button()
        Me.BtnOne = New System.Windows.Forms.Button()
        Me.BtnEquals = New System.Windows.Forms.Button()
        Me.BtnDecimal = New System.Windows.Forms.Button()
        Me.BtnZero = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtFinalNum
        '
        Me.txtFinalNum.Location = New System.Drawing.Point(2, 3)
        Me.txtFinalNum.Name = "txtFinalNum"
        Me.txtFinalNum.ReadOnly = True
        Me.txtFinalNum.Size = New System.Drawing.Size(139, 20)
        Me.txtFinalNum.TabIndex = 0
        '
        'BtnAC
        '
        Me.BtnAC.Location = New System.Drawing.Point(2, 29)
        Me.BtnAC.Name = "BtnAC"
        Me.BtnAC.Size = New System.Drawing.Size(31, 23)
        Me.BtnAC.TabIndex = 1
        Me.BtnAC.Text = "AC"
        Me.BtnAC.UseVisualStyleBackColor = True
        '
        'BtnPlusMinus
        '
        Me.BtnPlusMinus.Location = New System.Drawing.Point(39, 29)
        Me.BtnPlusMinus.Name = "BtnPlusMinus"
        Me.BtnPlusMinus.Size = New System.Drawing.Size(31, 23)
        Me.BtnPlusMinus.TabIndex = 2
        Me.BtnPlusMinus.Text = "+/-"
        Me.BtnPlusMinus.UseVisualStyleBackColor = True
        '
        'btnDivide
        '
        Me.btnDivide.Location = New System.Drawing.Point(110, 29)
        Me.btnDivide.Name = "btnDivide"
        Me.btnDivide.Size = New System.Drawing.Size(31, 23)
        Me.btnDivide.TabIndex = 3
        Me.btnDivide.Text = "/"
        Me.btnDivide.UseVisualStyleBackColor = True
        '
        'BtnPercent
        '
        Me.BtnPercent.Location = New System.Drawing.Point(76, 29)
        Me.BtnPercent.Name = "BtnPercent"
        Me.BtnPercent.Size = New System.Drawing.Size(31, 23)
        Me.BtnPercent.TabIndex = 4
        Me.BtnPercent.Text = "%"
        Me.BtnPercent.UseVisualStyleBackColor = True
        '
        'BtnSeven
        '
        Me.BtnSeven.Location = New System.Drawing.Point(2, 58)
        Me.BtnSeven.Name = "BtnSeven"
        Me.BtnSeven.Size = New System.Drawing.Size(31, 23)
        Me.BtnSeven.TabIndex = 5
        Me.BtnSeven.Text = "7"
        Me.BtnSeven.UseVisualStyleBackColor = True
        '
        'btnMultiply
        '
        Me.btnMultiply.Location = New System.Drawing.Point(110, 58)
        Me.btnMultiply.Name = "btnMultiply"
        Me.btnMultiply.Size = New System.Drawing.Size(31, 23)
        Me.btnMultiply.TabIndex = 6
        Me.btnMultiply.Text = "X"
        Me.btnMultiply.UseVisualStyleBackColor = True
        '
        'BtnNine
        '
        Me.BtnNine.Location = New System.Drawing.Point(76, 58)
        Me.BtnNine.Name = "BtnNine"
        Me.BtnNine.Size = New System.Drawing.Size(31, 23)
        Me.BtnNine.TabIndex = 7
        Me.BtnNine.Text = "9"
        Me.BtnNine.UseVisualStyleBackColor = True
        '
        'btnEight
        '
        Me.btnEight.Location = New System.Drawing.Point(39, 58)
        Me.btnEight.Name = "btnEight"
        Me.btnEight.Size = New System.Drawing.Size(31, 23)
        Me.btnEight.TabIndex = 8
        Me.btnEight.Text = "8"
        Me.btnEight.UseVisualStyleBackColor = True
        '
        'BtnMinus
        '
        Me.BtnMinus.Location = New System.Drawing.Point(110, 87)
        Me.BtnMinus.Name = "BtnMinus"
        Me.BtnMinus.Size = New System.Drawing.Size(31, 23)
        Me.BtnMinus.TabIndex = 9
        Me.BtnMinus.Text = "-"
        Me.BtnMinus.UseVisualStyleBackColor = True
        '
        'BtnSix
        '
        Me.BtnSix.Location = New System.Drawing.Point(76, 87)
        Me.BtnSix.Name = "BtnSix"
        Me.BtnSix.Size = New System.Drawing.Size(31, 23)
        Me.BtnSix.TabIndex = 10
        Me.BtnSix.Text = "6"
        Me.BtnSix.UseVisualStyleBackColor = True
        '
        'BtFive
        '
        Me.BtFive.Location = New System.Drawing.Point(39, 87)
        Me.BtFive.Name = "BtFive"
        Me.BtFive.Size = New System.Drawing.Size(31, 23)
        Me.BtFive.TabIndex = 11
        Me.BtFive.Text = "5"
        Me.BtFive.UseVisualStyleBackColor = True
        '
        'BtnFour
        '
        Me.BtnFour.Location = New System.Drawing.Point(2, 87)
        Me.BtnFour.Name = "BtnFour"
        Me.BtnFour.Size = New System.Drawing.Size(31, 23)
        Me.BtnFour.TabIndex = 12
        Me.BtnFour.Text = "4"
        Me.BtnFour.UseVisualStyleBackColor = True
        '
        'BtnThree
        '
        Me.BtnThree.Location = New System.Drawing.Point(76, 116)
        Me.BtnThree.Name = "BtnThree"
        Me.BtnThree.Size = New System.Drawing.Size(31, 23)
        Me.BtnThree.TabIndex = 13
        Me.BtnThree.Text = "3"
        Me.BtnThree.UseVisualStyleBackColor = True
        '
        'btnPlus
        '
        Me.btnPlus.Location = New System.Drawing.Point(110, 116)
        Me.btnPlus.Name = "btnPlus"
        Me.btnPlus.Size = New System.Drawing.Size(31, 23)
        Me.btnPlus.TabIndex = 14
        Me.btnPlus.Text = "+"
        Me.btnPlus.UseVisualStyleBackColor = True
        '
        'BtnTwo
        '
        Me.BtnTwo.Location = New System.Drawing.Point(39, 116)
        Me.BtnTwo.Name = "BtnTwo"
        Me.BtnTwo.Size = New System.Drawing.Size(31, 23)
        Me.BtnTwo.TabIndex = 15
        Me.BtnTwo.Text = "2"
        Me.BtnTwo.UseVisualStyleBackColor = True
        '
        'BtnOne
        '
        Me.BtnOne.Location = New System.Drawing.Point(2, 116)
        Me.BtnOne.Name = "BtnOne"
        Me.BtnOne.Size = New System.Drawing.Size(31, 23)
        Me.BtnOne.TabIndex = 16
        Me.BtnOne.Text = "1"
        Me.BtnOne.UseVisualStyleBackColor = True
        '
        'BtnEquals
        '
        Me.BtnEquals.Location = New System.Drawing.Point(110, 145)
        Me.BtnEquals.Name = "BtnEquals"
        Me.BtnEquals.Size = New System.Drawing.Size(31, 23)
        Me.BtnEquals.TabIndex = 17
        Me.BtnEquals.Text = "="
        Me.BtnEquals.UseVisualStyleBackColor = True
        '
        'BtnDecimal
        '
        Me.BtnDecimal.Location = New System.Drawing.Point(76, 145)
        Me.BtnDecimal.Name = "BtnDecimal"
        Me.BtnDecimal.Size = New System.Drawing.Size(31, 23)
        Me.BtnDecimal.TabIndex = 18
        Me.BtnDecimal.Text = "."
        Me.BtnDecimal.UseVisualStyleBackColor = True
        '
        'BtnZero
        '
        Me.BtnZero.Location = New System.Drawing.Point(2, 145)
        Me.BtnZero.Name = "BtnZero"
        Me.BtnZero.Size = New System.Drawing.Size(68, 23)
        Me.BtnZero.TabIndex = 19
        Me.BtnZero.Text = "0"
        Me.BtnZero.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(152, 177)
        Me.Controls.Add(Me.BtnZero)
        Me.Controls.Add(Me.BtnDecimal)
        Me.Controls.Add(Me.BtnEquals)
        Me.Controls.Add(Me.BtnOne)
        Me.Controls.Add(Me.BtnTwo)
        Me.Controls.Add(Me.btnPlus)
        Me.Controls.Add(Me.BtnThree)
        Me.Controls.Add(Me.BtnFour)
        Me.Controls.Add(Me.BtFive)
        Me.Controls.Add(Me.BtnSix)
        Me.Controls.Add(Me.BtnMinus)
        Me.Controls.Add(Me.btnEight)
        Me.Controls.Add(Me.BtnNine)
        Me.Controls.Add(Me.btnMultiply)
        Me.Controls.Add(Me.BtnSeven)
        Me.Controls.Add(Me.BtnPercent)
        Me.Controls.Add(Me.btnDivide)
        Me.Controls.Add(Me.BtnPlusMinus)
        Me.Controls.Add(Me.BtnAC)
        Me.Controls.Add(Me.txtFinalNum)
        Me.Name = "Form1"
        Me.Text = "Calulator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtFinalNum As TextBox
    Friend WithEvents BtnAC As Button
    Friend WithEvents BtnPlusMinus As Button
    Friend WithEvents btnDivide As Button
    Friend WithEvents BtnPercent As Button
    Friend WithEvents BtnSeven As Button
    Friend WithEvents btnMultiply As Button
    Friend WithEvents BtnNine As Button
    Friend WithEvents btnEight As Button
    Friend WithEvents BtnMinus As Button
    Friend WithEvents BtnSix As Button
    Friend WithEvents BtFive As Button
    Friend WithEvents BtnFour As Button
    Friend WithEvents BtnThree As Button
    Friend WithEvents btnPlus As Button
    Friend WithEvents BtnTwo As Button
    Friend WithEvents BtnOne As Button
    Friend WithEvents BtnEquals As Button
    Friend WithEvents BtnDecimal As Button
    Friend WithEvents BtnZero As Button
End Class
