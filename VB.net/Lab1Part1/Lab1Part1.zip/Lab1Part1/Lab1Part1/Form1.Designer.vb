﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblAirTemp = New System.Windows.Forms.Label()
        Me.txtAirTemp = New System.Windows.Forms.TextBox()
        Me.lblRelativeHumidty = New System.Windows.Forms.Label()
        Me.txtRelativeHumidity = New System.Windows.Forms.TextBox()
        Me.lblHeatIndex = New System.Windows.Forms.Label()
        Me.txtHeatIndex = New System.Windows.Forms.TextBox()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblAirTemp
        '
        Me.lblAirTemp.AutoSize = True
        Me.lblAirTemp.Location = New System.Drawing.Point(0, 10)
        Me.lblAirTemp.Name = "lblAirTemp"
        Me.lblAirTemp.Size = New System.Drawing.Size(91, 15)
        Me.lblAirTemp.TabIndex = 6
        Me.lblAirTemp.Text = "Air temperature"
        '
        'txtAirTemp
        '
        Me.txtAirTemp.Location = New System.Drawing.Point(98, 7)
        Me.txtAirTemp.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtAirTemp.Name = "txtAirTemp"
        Me.txtAirTemp.Size = New System.Drawing.Size(76, 21)
        Me.txtAirTemp.TabIndex = 0
        Me.txtAirTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblRelativeHumidty
        '
        Me.lblRelativeHumidty.AutoSize = True
        Me.lblRelativeHumidty.Location = New System.Drawing.Point(0, 39)
        Me.lblRelativeHumidty.Name = "lblRelativeHumidty"
        Me.lblRelativeHumidty.Size = New System.Drawing.Size(100, 15)
        Me.lblRelativeHumidty.TabIndex = 7
        Me.lblRelativeHumidty.Text = "Relative humidity"
        '
        'txtRelativeHumidity
        '
        Me.txtRelativeHumidity.Location = New System.Drawing.Point(98, 36)
        Me.txtRelativeHumidity.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtRelativeHumidity.Name = "txtRelativeHumidity"
        Me.txtRelativeHumidity.Size = New System.Drawing.Size(76, 21)
        Me.txtRelativeHumidity.TabIndex = 1
        Me.txtRelativeHumidity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblHeatIndex
        '
        Me.lblHeatIndex.AutoSize = True
        Me.lblHeatIndex.Location = New System.Drawing.Point(0, 67)
        Me.lblHeatIndex.Name = "lblHeatIndex"
        Me.lblHeatIndex.Size = New System.Drawing.Size(65, 15)
        Me.lblHeatIndex.TabIndex = 8
        Me.lblHeatIndex.Text = "Heat index"
        '
        'txtHeatIndex
        '
        Me.txtHeatIndex.Location = New System.Drawing.Point(98, 67)
        Me.txtHeatIndex.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtHeatIndex.Name = "txtHeatIndex"
        Me.txtHeatIndex.ReadOnly = True
        Me.txtHeatIndex.Size = New System.Drawing.Size(76, 21)
        Me.txtHeatIndex.TabIndex = 2
        Me.txtHeatIndex.TabStop = False
        Me.txtHeatIndex.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(3, 97)
        Me.btnCalc.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(87, 26)
        Me.btnCalc.TabIndex = 3
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(98, 97)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(87, 26)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(203, 97)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(87, 26)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(306, 137)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.txtHeatIndex)
        Me.Controls.Add(Me.lblHeatIndex)
        Me.Controls.Add(Me.txtRelativeHumidity)
        Me.Controls.Add(Me.lblRelativeHumidty)
        Me.Controls.Add(Me.txtAirTemp)
        Me.Controls.Add(Me.lblAirTemp)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "Form1"
        Me.Text = "Heat Index"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblAirTemp As Label
    Friend WithEvents txtAirTemp As TextBox
    Friend WithEvents lblRelativeHumidty As Label
    Friend WithEvents txtRelativeHumidity As TextBox
    Friend WithEvents lblHeatIndex As Label
    Friend WithEvents txtHeatIndex As TextBox
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
