﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtPayRate = New System.Windows.Forms.TextBox()
        Me.TxtHoursWorked = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TxtPay = New System.Windows.Forms.TextBox()
        Me.BtnStart = New System.Windows.Forms.Button()
        Me.BtnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(0, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Pay rate:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(0, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Hours worked:"
        '
        'TxtPayRate
        '
        Me.TxtPayRate.Location = New System.Drawing.Point(55, 6)
        Me.TxtPayRate.Name = "TxtPayRate"
        Me.TxtPayRate.Size = New System.Drawing.Size(47, 20)
        Me.TxtPayRate.TabIndex = 0
        '
        'TxtHoursWorked
        '
        Me.TxtHoursWorked.Location = New System.Drawing.Point(82, 31)
        Me.TxtHoursWorked.Name = "TxtHoursWorked"
        Me.TxtHoursWorked.Size = New System.Drawing.Size(53, 20)
        Me.TxtHoursWorked.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(0, 67)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(25, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Pay"
        '
        'TxtPay
        '
        Me.TxtPay.Location = New System.Drawing.Point(35, 64)
        Me.TxtPay.Name = "TxtPay"
        Me.TxtPay.Size = New System.Drawing.Size(67, 20)
        Me.TxtPay.TabIndex = 2
        Me.TxtPay.TabStop = False
        '
        'BtnStart
        '
        Me.BtnStart.Location = New System.Drawing.Point(3, 101)
        Me.BtnStart.Name = "BtnStart"
        Me.BtnStart.Size = New System.Drawing.Size(75, 23)
        Me.BtnStart.TabIndex = 3
        Me.BtnStart.Text = "Start"
        Me.BtnStart.UseVisualStyleBackColor = True
        '
        'BtnExit
        '
        Me.BtnExit.Location = New System.Drawing.Point(146, 101)
        Me.BtnExit.Name = "BtnExit"
        Me.BtnExit.Size = New System.Drawing.Size(75, 23)
        Me.BtnExit.TabIndex = 4
        Me.BtnExit.Text = "Exit"
        Me.BtnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.BtnExit)
        Me.Controls.Add(Me.BtnStart)
        Me.Controls.Add(Me.TxtPay)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TxtHoursWorked)
        Me.Controls.Add(Me.TxtPayRate)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Payroll"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TxtPayRate As TextBox
    Friend WithEvents TxtHoursWorked As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TxtPay As TextBox
    Friend WithEvents BtnStart As Button
    Friend WithEvents BtnExit As Button
End Class
