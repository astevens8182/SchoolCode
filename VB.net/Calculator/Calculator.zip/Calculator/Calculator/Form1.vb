﻿'Project: Calculator
'Author: Alex Stevens
'Date :  7/17/2018
Option Strict On
Public Class Form1
    Const one As Char = "1"c
    Const two As Char = "2"c
    Const three As Char = "3"c
    Const four As Char = "4"c
    Const five As Char = "5"c
    Const six As Char = "6"c
    Const seven As Char = "7"c
    Const eight As Char = "8"c
    Const nine As Char = "9"c
    Const zero As Char = "0"c

    Do

    Loop Until

    Private Sub txtFinalNum_TextChanged(sender As Object, e As EventArgs) Handles txtFinalNum.TextChanged

    End Sub
End Class
