﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtEmpNumber = New System.Windows.Forms.TextBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnClac = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtDepartmentNumber = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtStateOfWork = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtWithholdingnum = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtYTD = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbxEmploymentType = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtempttpe1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtempltype2 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(0, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(103, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Employee's Number:"
        '
        'txtEmpNumber
        '
        Me.txtEmpNumber.Location = New System.Drawing.Point(109, 48)
        Me.txtEmpNumber.Name = "txtEmpNumber"
        Me.txtEmpNumber.Size = New System.Drawing.Size(100, 20)
        Me.txtEmpNumber.TabIndex = 2
        Me.txtEmpNumber.Tag = "Employee Number"
        '
        'btnClear
        '
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClear.Location = New System.Drawing.Point(215, 35)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(215, 64)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnClac
        '
        Me.btnClac.Location = New System.Drawing.Point(215, 6)
        Me.btnClac.Name = "btnClac"
        Me.btnClac.Size = New System.Drawing.Size(75, 23)
        Me.btnClac.TabIndex = 7
        Me.btnClac.Text = "Calculate"
        Me.btnClac.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(0, 6)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 13)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "First Name:"
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(109, 3)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(100, 20)
        Me.txtFirstName.TabIndex = 0
        Me.txtFirstName.Tag = "First Name"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(0, 29)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(61, 13)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Last Name:"
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(109, 26)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(100, 20)
        Me.txtLastName.TabIndex = 1
        Me.txtLastName.Tag = "Last Name"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(0, 75)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(105, 13)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Department Number:"
        '
        'txtDepartmentNumber
        '
        Me.txtDepartmentNumber.Location = New System.Drawing.Point(109, 72)
        Me.txtDepartmentNumber.Name = "txtDepartmentNumber"
        Me.txtDepartmentNumber.Size = New System.Drawing.Size(100, 20)
        Me.txtDepartmentNumber.TabIndex = 3
        Me.txtDepartmentNumber.Tag = "Department Number"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(0, 100)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(76, 13)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "State of Work:"
        '
        'txtStateOfWork
        '
        Me.txtStateOfWork.Location = New System.Drawing.Point(109, 97)
        Me.txtStateOfWork.Name = "txtStateOfWork"
        Me.txtStateOfWork.Size = New System.Drawing.Size(100, 20)
        Me.txtStateOfWork.TabIndex = 4
        Me.txtStateOfWork.Tag = "State of Work"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(0, 130)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(123, 13)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Withholding Allowances:"
        '
        'txtWithholdingnum
        '
        Me.txtWithholdingnum.Location = New System.Drawing.Point(129, 127)
        Me.txtWithholdingnum.Name = "txtWithholdingnum"
        Me.txtWithholdingnum.Size = New System.Drawing.Size(80, 20)
        Me.txtWithholdingnum.TabIndex = 5
        Me.txtWithholdingnum.Tag = "Withholding Allowances"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(0, 153)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(32, 13)
        Me.Label10.TabIndex = 17
        Me.Label10.Text = "YTD:"
        '
        'txtYTD
        '
        Me.txtYTD.Location = New System.Drawing.Point(109, 153)
        Me.txtYTD.Name = "txtYTD"
        Me.txtYTD.Size = New System.Drawing.Size(100, 20)
        Me.txtYTD.TabIndex = 6
        Me.txtYTD.Tag = "YTD"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(0, 184)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(94, 13)
        Me.Label2.TabIndex = 18
        Me.Label2.Text = "Employment Type:"
        '
        'cbxEmploymentType
        '
        Me.cbxEmploymentType.FormattingEnabled = True
        Me.cbxEmploymentType.Location = New System.Drawing.Point(109, 179)
        Me.cbxEmploymentType.Name = "cbxEmploymentType"
        Me.cbxEmploymentType.Size = New System.Drawing.Size(100, 21)
        Me.cbxEmploymentType.TabIndex = 19
        Me.cbxEmploymentType.Tag = "Employment Type"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(0, 213)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 13)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Hours Worked"
        '
        'txtempttpe1
        '
        Me.txtempttpe1.Location = New System.Drawing.Point(109, 210)
        Me.txtempttpe1.Name = "txtempttpe1"
        Me.txtempttpe1.Size = New System.Drawing.Size(100, 20)
        Me.txtempttpe1.TabIndex = 21
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(0, 239)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 13)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "Pay Rate"
        '
        'txtempltype2
        '
        Me.txtempltype2.Location = New System.Drawing.Point(109, 236)
        Me.txtempltype2.Name = "txtempltype2"
        Me.txtempltype2.Size = New System.Drawing.Size(100, 20)
        Me.txtempltype2.TabIndex = 23
        '
        'Form1
        '
        Me.AcceptButton = Me.btnClac
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(298, 266)
        Me.Controls.Add(Me.txtempltype2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtempttpe1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cbxEmploymentType)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtYTD)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtWithholdingnum)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtStateOfWork)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtDepartmentNumber)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnClac)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.txtEmpNumber)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Payroll"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtEmpNumber As TextBox
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnClac As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtDepartmentNumber As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtStateOfWork As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtWithholdingnum As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtYTD As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents cbxEmploymentType As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtempttpe1 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtempltype2 As TextBox
End Class
