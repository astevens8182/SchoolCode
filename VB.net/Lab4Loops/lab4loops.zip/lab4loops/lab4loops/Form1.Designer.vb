﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.radIdaho = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.radNevada = New System.Windows.Forms.RadioButton()
        Me.radUtah = New System.Windows.Forms.RadioButton()
        Me.radWashington = New System.Windows.Forms.RadioButton()
        Me.radFlorida = New System.Windows.Forms.RadioButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtyears = New System.Windows.Forms.TextBox()
        Me.txtreport = New System.Windows.Forms.TextBox()
        Me.btncalc = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'radIdaho
        '
        Me.radIdaho.AutoSize = True
        Me.radIdaho.Location = New System.Drawing.Point(5, 25)
        Me.radIdaho.Name = "radIdaho"
        Me.radIdaho.Size = New System.Drawing.Size(52, 17)
        Me.radIdaho.TabIndex = 0
        Me.radIdaho.TabStop = True
        Me.radIdaho.Text = "Idaho"
        Me.radIdaho.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(2, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "States:"
        '
        'radNevada
        '
        Me.radNevada.AutoSize = True
        Me.radNevada.Location = New System.Drawing.Point(63, 25)
        Me.radNevada.Name = "radNevada"
        Me.radNevada.Size = New System.Drawing.Size(63, 17)
        Me.radNevada.TabIndex = 1
        Me.radNevada.TabStop = True
        Me.radNevada.Text = "Nevada"
        Me.radNevada.UseVisualStyleBackColor = True
        '
        'radUtah
        '
        Me.radUtah.AutoSize = True
        Me.radUtah.Location = New System.Drawing.Point(132, 25)
        Me.radUtah.Name = "radUtah"
        Me.radUtah.Size = New System.Drawing.Size(48, 17)
        Me.radUtah.TabIndex = 2
        Me.radUtah.TabStop = True
        Me.radUtah.Text = "Utah"
        Me.radUtah.UseVisualStyleBackColor = True
        '
        'radWashington
        '
        Me.radWashington.AutoSize = True
        Me.radWashington.Location = New System.Drawing.Point(186, 25)
        Me.radWashington.Name = "radWashington"
        Me.radWashington.Size = New System.Drawing.Size(82, 17)
        Me.radWashington.TabIndex = 3
        Me.radWashington.TabStop = True
        Me.radWashington.Text = "Washington"
        Me.radWashington.UseVisualStyleBackColor = True
        '
        'radFlorida
        '
        Me.radFlorida.AutoSize = True
        Me.radFlorida.Location = New System.Drawing.Point(274, 25)
        Me.radFlorida.Name = "radFlorida"
        Me.radFlorida.Size = New System.Drawing.Size(56, 17)
        Me.radFlorida.TabIndex = 4
        Me.radFlorida.TabStop = True
        Me.radFlorida.Text = "Florida"
        Me.radFlorida.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(90, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Number of years: "
        '
        'txtyears
        '
        Me.txtyears.Location = New System.Drawing.Point(5, 61)
        Me.txtyears.Name = "txtyears"
        Me.txtyears.Size = New System.Drawing.Size(52, 20)
        Me.txtyears.TabIndex = 5
        '
        'txtreport
        '
        Me.txtreport.Location = New System.Drawing.Point(12, 132)
        Me.txtreport.Multiline = True
        Me.txtreport.Name = "txtreport"
        Me.txtreport.ReadOnly = True
        Me.txtreport.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtreport.Size = New System.Drawing.Size(307, 102)
        Me.txtreport.TabIndex = 8
        '
        'btncalc
        '
        Me.btncalc.Location = New System.Drawing.Point(5, 87)
        Me.btncalc.Name = "btncalc"
        Me.btncalc.Size = New System.Drawing.Size(75, 23)
        Me.btncalc.TabIndex = 6
        Me.btncalc.Text = "Calculate"
        Me.btncalc.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(86, 87)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 7
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(167, 87)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.btncalc
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(338, 236)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btncalc)
        Me.Controls.Add(Me.txtreport)
        Me.Controls.Add(Me.txtyears)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.radFlorida)
        Me.Controls.Add(Me.radWashington)
        Me.Controls.Add(Me.radUtah)
        Me.Controls.Add(Me.radNevada)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.radIdaho)
        Me.Name = "Form1"
        Me.Text = "Population Growth "
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents radIdaho As RadioButton
    Friend WithEvents Label1 As Label
    Friend WithEvents radNevada As RadioButton
    Friend WithEvents radUtah As RadioButton
    Friend WithEvents radWashington As RadioButton
    Friend WithEvents radFlorida As RadioButton
    Friend WithEvents Label2 As Label
    Friend WithEvents txtyears As TextBox
    Friend WithEvents txtreport As TextBox
    Friend WithEvents btncalc As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
